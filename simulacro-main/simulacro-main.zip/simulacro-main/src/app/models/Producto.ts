export interface Producto {
  id: string;
  name: string;
  price: number;
  stock: number;
  category: string;
}